package com.example.commonui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.WindowManager

class MainActivity : AppCompatActivity() {


}