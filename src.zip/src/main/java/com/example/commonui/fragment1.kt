package com.example.commonui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup


class fragment1 : Fragment(R.layout.fragment_j) {

}